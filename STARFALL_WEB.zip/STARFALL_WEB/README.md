# STARFALL – Browser-Version

Diese Version ist für pygbag vorbereitet. `main.py` ist die Browser-Fassung des Spiels.

## Lokal testen
1. `python3 -m pip install --upgrade pygbag pygame-ce`
2. Im Ordner oberhalb von `STARFALL_WEB`: `python3 -m pygbag STARFALL_WEB`
3. In Chrome `http://localhost:8000` öffnen.

## Öffentlichen Link erstellen
Baue die Webdateien mit `python3 -m pygbag --build STARFALL_WEB`. Veröffentliche danach den Inhalt von `STARFALL_WEB/build/web` über GitHub Pages.

Beim ersten Browserstart kann WebAssembly etwas länger laden.
